# Architecture Overview

## System shape

Daymark is a single Python process that serves a local web UI and watches the filesystem.

```
┌──────────────────────────────────────────────────┐
│  Browser (localhost:PORT)                         │
│  ┌────────────────────────────────────────────┐   │
│  │  Static frontend: HTML + JS + CSS          │   │
│  │  Kanban board, card detail/edit panel       │   │
│  │  Drag-and-drop → POST to backend           │   │
│  │  WebSocket ← live reload on file changes   │   │
│  └────────────────────────────────────────────┘   │
└──────────────┬────────────────────┬───────────────┘
               │ HTTP/WS            │
┌──────────────▼────────────────────▼───────────────┐
│  Python server (uvicorn / starlette)              │
│                                                    │
│  ┌─────────────┐  ┌─────────────┐  ┌───────────┐ │
│  │ Scanner     │  │ Mutator     │  │ Watcher   │ │
│  │             │  │             │  │           │ │
│  │ Walks docs/ │  │ Writes      │  │ fswatch / │ │
│  │ Parses FM   │  │ frontmatter │  │ watchfiles│ │
│  │ Builds card │  │ Moves files │  │           │ │
│  │ index       │  │ on drag-drop│  │ Pushes WS │ │
│  └─────────────┘  └─────────────┘  │ on change │ │
│                                     └───────────┘ │
│  ┌─────────────────────────────────────────────┐  │
│  │ Tracks config (daymark.tracks.yml)          │  │
│  │ - column_field, scan_paths, tracks,         │  │
│  │   phase order, terminal states, match rules │  │
│  └─────────────────────────────────────────────┘  │
└───────────────────────┬───────────────────────────┘
                        │ filesystem
┌───────────────────────▼───────────────────────────┐
│  Your markdown files                               │
│  docs/spec/Complete/(SPEC-014)-Fix-Bug/SPEC-014.md │
│  docs/epic/Proposed/(EPIC-016)-Bookmarks/...       │
│  blog/drafts/my-post.md                            │
│  ...                                               │
└────────────────────────────────────────────────────┘
```

## Components

### Scanner

On startup and on filesystem change events, the scanner walks configured `scan_paths`, finds `.md` files, parses YAML frontmatter with `python-frontmatter`, and builds an in-memory index of cards. Each card holds:

- `path`: absolute file path
- `relative_path`: path relative to project root
- `frontmatter`: full parsed YAML dict
- `column_value`: the value of the configured `column_field` (e.g., `status: Proposed`)
- `track`: resolved track name (from frontmatter field, or inferred via match rules)
- `title`: from frontmatter `title` field, or filename
- `artifact_id`: from frontmatter if present (e.g., `SPEC-014`)
- `body`: markdown body (loaded on demand for detail view, not held in memory for all cards)

The scanner re-indexes only changed files on watch events, not the full tree.

### Tracks config

A single YAML file that tells Daymark how to interpret the markdown collection. Loaded once at startup, re-read on change.

```yaml
# What frontmatter field determines the column
column_field: status

# Where to look for markdown files
scan_paths:
  - docs/

# Optional: frontmatter field that directly declares the track
track_field: track

# Track definitions
tracks:
  implementable:
    match:
      track: implementable
    phases: [Proposed, Ready, Active, Complete]
    terminal: [Complete, Abandoned, Retired, Superseded]
    enforce_order: true

  container:
    match:
      track: container
    phases: [Proposed, Active, Complete]
    terminal: [Complete, Abandoned, Retired, Superseded]
    enforce_order: true

  standing:
    match:
      track: standing
    phases: [Proposed, Active]
    terminal: [Active, Retired, Superseded]
    enforce_order: true

# Fallback for files with no track match
defaults:
  track: implementable
  terminal: []
```

The `match` block supports matching on any frontmatter field. If a `track_field` is configured and the file has that field, it takes precedence. Otherwise, match rules are evaluated in definition order.

### Mutator

Handles write operations triggered by the UI:

- **Move card (drag-and-drop):** Updates the `column_field` value in the file's YAML frontmatter. If the project uses phase subdirectories (detected by the presence of a `phase_directories` config flag or auto-detected from the scan path structure), also performs a filesystem move to the corresponding subdirectory.
- **Edit frontmatter field:** Writes a single field update to the YAML block without reformatting the rest of the file.
- **Edit body:** Writes the markdown body, preserving the frontmatter block verbatim.

All writes use atomic file operations (write to temp, rename) to avoid corruption on crash.

### Watcher

Uses `watchfiles` (or `watchdog`) to monitor the configured scan paths. On file create/modify/delete/move events:

1. Re-scans affected files only (not full tree).
2. Updates the in-memory card index.
3. Pushes a WebSocket message to connected browsers with the delta.

The watcher debounces events (100ms) to coalesce rapid changes (e.g., a `git mv` that produces delete + create).

### Frontend

Static HTML + vanilla JS + CSS. No build step, no framework dependency. Served by the Python process from a bundled `static/` directory.

Core views:

- **Board view:** Columns derived from the tracks config. Cards rendered as draggable elements. Grouped by track (tabs or swimlanes — TBD based on card volume). Terminal-phase columns can be collapsed.
- **Card detail panel:** Slide-out or modal. Shows rendered markdown (title, frontmatter fields, body preview). Edit button opens an inline editor for frontmatter fields and body text.
- **Filter/search bar:** Filter by track, artifact type, text search across title and body.

The frontend receives the full card index on initial load via a JSON endpoint, then receives incremental updates over WebSocket.

## Data flow

```
Startup:
  1. Load daymark.tracks.yml
  2. Walk scan_paths, parse all .md files
  3. Build card index in memory
  4. Start watcher on scan_paths
  5. Start HTTP server on localhost:PORT
  6. Serve frontend, expose /api/cards, /api/tracks, /ws

Drag-and-drop:
  1. Frontend POST /api/cards/{id}/move {target_column}
  2. Mutator validates transition (if enforce_order)
  3. Mutator updates frontmatter on disk
  4. Mutator moves file to phase subdirectory (if applicable)
  5. Watcher picks up change → re-scans file → pushes WS update
  6. Frontend moves card to new column

External edit (user edits file in vim/vscode):
  1. Watcher detects file change
  2. Scanner re-parses affected file
  3. Card index updated
  4. WS push to frontend
  5. Board re-renders affected card
```

## Packaging

Distributed as a Python package on PyPI: `daymark-md`.

```bash
# Run without installing
uvx daymark-md

# Or install into a project
uv add daymark-md
daymark-md
```

Entry point reads `daymark.tracks.yml` from the current directory (or a path passed as `--config`). Serves on `localhost:3141` by default (π — a navigational constant).

## Future considerations

These are not planned, but the architecture should not preclude them:

- **Git integration:** Show lifecycle commit hashes on cards, link to diffs.
- **Relationship graph:** Render `depends-on-artifacts` and `linked-artifacts` as edges between cards (swain's specgraph does this in CLI; Daymark could visualize it).
- **Multiple boards:** Tabs or a board picker for different scan paths or track subsets.
- **Plugin hooks:** Optional pre/post-move hooks for workflow tools that want to run validation on transitions.
