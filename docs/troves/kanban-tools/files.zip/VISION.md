# Daymark Vision

**A fixed reference point for navigating your markdown.**

Daymark is a local web application that renders any collection of markdown files as an interactive kanban board. It reads YAML frontmatter to determine which column each file belongs to, and lets you drag cards between columns to update that frontmatter on disk. It opens files for viewing and editing. It watches the filesystem and reflects external changes in real time.

Daymark does not own your data. Your files stay where they are, in whatever folder structure you already use, with whatever frontmatter schema you already have. Daymark reads a small tracks definition file that tells it which field to group by, what the valid columns are, and in what order — then it gets out of the way.

## Origin

Daymark was built as a visual companion to [swain](https://github.com/cristoslc/swain), a skill suite for solo developers working with AI coding agents. Swain produces structured markdown artifacts (Visions, Epics, Specs, Spikes, ADRs) that move through lifecycle phases tracked in YAML frontmatter and phase subdirectories. The artifacts are inspectable and diffable, but reading a directory tree to understand project state is tedious. Daymark gives that tree a face.

The tool is generic by design. Any project that stores work items as markdown files with a frontmatter field encoding their current stage can use Daymark — a blog drafting pipeline, a research note workflow, a documentation lifecycle, or anything else where the unit of work is a `.md` file.

## Principles

**Your files are the source of truth.** Daymark has no database, no sync layer, no shadow state. It reads markdown, writes markdown, and watches the filesystem. If you edit a file in your text editor, Daymark reflects the change. If Daymark moves a card, the file changes on disk.

**Configuration lives in one file.** A single `daymark.tracks.yml` (or equivalent) declares the frontmatter field that drives columns, the tracks and their phase sequences, and how to match artifacts to tracks. No hidden state, no generated config.

**Transitions are the user's responsibility.** Daymark can enforce forward-only phase ordering if the tracks file says so, or it can be fully permissive. It does not run hooks, scripts, or validation — that's your workflow tool's job (swain, make, CI, whatever). Daymark shows you the board and moves the files.

**Local-first, single-user, zero-network.** Daymark runs on your machine, serves to localhost, makes no outbound requests. It reads your filesystem and that's it.

## Non-goals

- Multiplayer / collaboration features
- Cloud sync or hosted mode
- Replacing your text editor (Daymark is for triage and navigation, not authoring)
- Running lifecycle hooks or enforcing workflow rules beyond column ordering
- Supporting non-markdown file formats
