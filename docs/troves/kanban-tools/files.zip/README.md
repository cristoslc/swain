# daymark-md

**A kanban board for your markdown files.**

Daymark reads a folder of markdown files, groups them into columns by a YAML frontmatter field, and renders an interactive kanban board in your browser. Drag a card to a new column and Daymark updates the frontmatter on disk. Edit a file in your text editor and the board updates in real time.

No database. No sync service. No account. Your files are the board.

Named for the [daymark](https://en.wikipedia.org/wiki/Daymark) — a fixed navigational reference that helps pilots read the channel without moving anything itself.

## Quick start

```bash
uvx daymark-md
```

Daymark looks for `daymark.tracks.yml` in the current directory, scans the configured paths for `.md` files, and opens a board at `http://localhost:3141`.

## Tracks file

Daymark needs one configuration file to know how to read your markdown. Create `daymark.tracks.yml` in your project root:

```yaml
column_field: status

scan_paths:
  - docs/

tracks:
  default:
    phases: [Draft, Review, Published]
    terminal: [Published, Archived]
```

That's the minimal case — a single track with three columns driven by the `status` field in each file's frontmatter.

### Multi-track example (swain)

For projects with multiple artifact types that follow different lifecycles:

```yaml
column_field: status
track_field: track

scan_paths:
  - docs/

tracks:
  implementable:
    match:
      track: implementable
    phases: [Proposed, Ready, Active, Complete]
    terminal: [Complete, Abandoned, Retired, Superseded]
    enforce_order: true

  container:
    match:
      track: container
    phases: [Proposed, Active, Complete]
    terminal: [Complete, Abandoned, Retired, Superseded]
    enforce_order: true

  standing:
    match:
      track: standing
    phases: [Proposed, Active]
    terminal: [Active, Retired, Superseded]
    enforce_order: true

defaults:
  track: implementable
```

### Tracks file reference

| Field | Required | Description |
|-------|----------|-------------|
| `column_field` | yes | Frontmatter field used to determine which column a card belongs to |
| `scan_paths` | yes | List of directories to scan for `.md` files (relative to project root) |
| `track_field` | no | Frontmatter field that directly declares an artifact's track |
| `tracks` | yes | Map of track names to their definitions |
| `tracks.<name>.match` | no | Frontmatter field/value pairs that assign a file to this track |
| `tracks.<name>.phases` | yes | Ordered list of column names for this track |
| `tracks.<name>.terminal` | no | Phases treated as "done" (collapsed by default in the UI) |
| `tracks.<name>.enforce_order` | no | If `true`, cards can only move forward in the phase sequence |
| `defaults.track` | no | Track to assign when no match rule applies |

### Phase subdirectories

If your files live in folders named after their phase (e.g., `docs/spec/Complete/...`), Daymark detects this automatically and moves files between subdirectories when you drag cards. This is optional — if your files are in a flat folder, only the frontmatter is updated.

## What it does

- Scans directories for `.md` files and parses YAML frontmatter
- Renders cards in columns based on a configurable frontmatter field
- Drag-and-drop between columns updates frontmatter (and moves files if using phase subdirectories)
- Watches the filesystem and live-updates the board when files change externally
- Opens files for viewing rendered markdown and editing frontmatter
- Supports multiple lifecycle tracks with different phase sequences
- Optionally enforces forward-only transitions per track

## What it doesn't do

- Replace your text editor — Daymark is for triage and navigation
- Run hooks, scripts, or CI on transitions — that's your workflow tool's job
- Store anything outside your existing files — no database, no dotfile state
- Make network requests — fully local, fully offline

## Usage

```bash
# Run from a project directory with daymark.tracks.yml
uvx daymark-md

# Specify a config file
uvx daymark-md --config path/to/daymark.tracks.yml

# Specify a port
uvx daymark-md --port 8080

# Open browser automatically
uvx daymark-md --open
```

## Requirements

- Python 3.11+
- A folder of markdown files with YAML frontmatter

## Development

```bash
git clone https://github.com/cristoslc/daymark-md.git
cd daymark-md
uv sync
uv run daymark-md
```

## License

MIT
